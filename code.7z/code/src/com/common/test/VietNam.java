package com.common.test;

public class VietNam {
	public static String DATA_FILE_INPUT = "data/dataFacebook_v22.csv";
	public static String DATA_FILE_OUTPUT = "data/dataFacebook_v222.csv";

	public static void main(String agr[]) {
		Integer a = 1, b = 10000;
		System.out.println((double) a / b);
		// tokenizer.segment("");
		// tokenizer.tokenize(DATA_FILE_INPUT, DATA_FILE_OUTPUT);
		// DetectLanguage.apiKey = "ef108ab62228dd0d2da7b9a399f3a285";
		// String language = DetectLanguage.simpleDetect("toàn_thân");
		// System.out.println(language);
		// VietTokenizer viet = new VietTokenizer();
	}
}
