package com.socialnetwork.model;

public class CommentObject extends MessageObject {
	public CommentObject() {
		super();
	}

	public CommentObject(String id, String message) {
		super();
	}
}
