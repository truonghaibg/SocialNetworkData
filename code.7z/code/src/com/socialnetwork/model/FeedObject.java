package com.socialnetwork.model;

public class FeedObject extends MessageObject {
	public FeedObject() {
		super();
	}

	public FeedObject(String id, String message) {
		super();
	}
}
